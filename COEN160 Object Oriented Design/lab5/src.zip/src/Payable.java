import java.math.BigDecimal;

public interface Payable {
    public abstract BigDecimal getAmountToPay();
}
